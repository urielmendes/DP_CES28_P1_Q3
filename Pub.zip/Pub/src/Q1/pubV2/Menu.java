package Q1.pubV2;

import java.util.HashMap;
import java.util.Map;

public class Menu {
	
	//Classe que possui o controle dos precos
	
	//Agora esta mais facil adicionar drinks e modificar precos
	
	private Map<String,Integer> _priceTable;
	
	public Menu(){
		_priceTable = new HashMap<String, Integer>();
		_priceTable.put("hansa", 74);
		_priceTable.put("grans", 103);
		_priceTable.put("strongbow", 110);
		_priceTable.put("gt", ingredient4()+ingredient5()+ingredient6());
		_priceTable.put("bacardi_special", ingredient1()+ingredient2()+
				ingredient3()+ingredient6());
	}
	
	//Retorna preco da bebida
	public int getPrice(String drink){
		return _priceTable.get(drink);
	}
	
	//Checa se o drink esta no cardapio
	public boolean isOnTheMenu(String drink){
		return _priceTable.containsKey(drink);
	}
	
	/////Estes campos foram deslocados da classe Pub
	
	//one unit of rum
    private int ingredient1() {
        return 65;
    }

    //one unit of grenadine
    private int ingredient2() {
        return 10;
    }

    //one unit of lime juice
    private int ingredient3() {
        return 10;
    }

    //one unit of green stuff
    private int ingredient4() {
        return 10;
    }

    //one unit of tonic water
    private int ingredient5() {
        return 20;
    }

    //one unit of gin
    private int ingredient6() {
        return 85;
    }
	
	
}
