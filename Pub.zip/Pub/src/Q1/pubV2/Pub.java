package Q1.pubV2;


public class Pub {

	///Encapsulate fields////////////////////////////
	//////Foram removidos campos desnecessarios
    private static final String GT = "gt";
    private static final String BACARDI_SPECIAL = "bacardi_special";
    private Menu _menu;
    /////////////////////////////////////////////////
    
    public Pub(){
    	_menu = new Menu();
    }
    
    public int computeCost(String drink, boolean student, int amount) {

    	////////////Checa se o drink esta no cardapio///////
    	if(!_menu.isOnTheMenu(drink))
    		throw new RuntimeException("No such drink exists");  
    	////////////////////////////////////////////////////
    	
    	///////Calcular preço base////////////
    	int price;
    	price = _menu.getPrice(drink);
    	///////////////////////////////////
    	
    	if(drink == GT || drink == BACARDI_SPECIAL){
    		if(amount > 2) ////Bebeu demais
    			throw new RuntimeException("Too many drinks, max 2.");	
    	}
    	else if(student) /////Desconto para estudantes
    			price = (int) Math.ceil(price - price/10);

        return price*amount;
    }
    
}
